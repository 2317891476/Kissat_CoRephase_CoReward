#!/bin/bash

# Run SAT solver
./build/kissat --time=5000 $1