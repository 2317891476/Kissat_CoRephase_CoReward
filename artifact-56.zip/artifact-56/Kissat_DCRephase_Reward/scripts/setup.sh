#!/bin/bash

# Update package list and install required packages
sudo apt-get update
apt-get install p7zip-full

# Install drabt
cd env/drabt-004
make
cd ../..

# Build the SAT solver
make clean
./configure 
make 
cd ../
